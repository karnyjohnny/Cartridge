# CARTRIDGE — Technical Agent Execution Specification

**Document type:** executable project brief for an autonomous coding agent  
**Product:** local desktop game collection manager  
**Working name:** Cartridge  
**Target runtime:** Windows 7 SP1 x64  
**Python target:** Python 3.8.x, preferably the established Python 3.8.20 x64 environment  
**GUI baseline:** PyQt5 5.15.x, with the already verified local installation preferred unless a concrete incompatibility is demonstrated  
**HTTP client:** `httpx`  
**Persistence:** SQLite  
**License:** MIT  
**Primary UI reference:** the user-supplied `ui-reference.html`

---

## 0. Execution contract

You are responsible for delivering a complete, maintainable, runnable desktop application—not merely a proposal, mock-up, or large collection of source files.

This document defines the required outcome, platform constraints, operating procedure, and acceptance criteria. It intentionally leaves internal class design, module boundaries, SQL schema details, and other implementation choices to the engineering agent, provided that the implementation meets the requirements and remains compatible with the target environment.

Use these normative terms consistently:

- **MUST / MUST NOT:** mandatory requirement or prohibition.
- **SHOULD / SHOULD NOT:** strong recommendation; deviations require a recorded technical reason.
- **MAY:** optional implementation choice.

A requirement is not satisfied merely because code has been written. It is satisfied only when the applicable behavior has been tested and the result recorded accurately.

### Primary objective

Build a polished, responsive, dark-mode game collection manager that works on the user's actual Windows 7 machine, uses Python 3.8.x and `httpx`, stores structured data in SQLite, and organizes an existing collection of game directories without damaging or reorganizing the user's files.

### Engineering priorities

1. Runtime compatibility.
2. Correctness and data safety.
3. Reliability and recoverability.
4. Clear, efficient user experience.
5. Measured performance on constrained hardware.
6. Maintainability.
7. Visual polish.

Do not optimize one priority by silently violating a higher-priority requirement.

---

## 1. Safety, scope, and interruption handling

This is a benign local desktop application for cataloguing game folders, metadata, and artwork. Keep implementation and tests inside that scope.

### Scope boundaries

The application MUST NOT add unrelated functionality involving malware, credential theft, stealth, persistence, exploit development, privilege escalation, unauthorized remote access, surveillance, or destructive filesystem operations. Do not add code-obfuscation or anti-analysis behavior. Do not execute files merely because they were discovered during a scan. Any optional game-launch action must require an explicit user action and a validated, user-selected executable path.

Treat filenames, directory contents, API responses, JSON, URLs, image bytes, and imported metadata as untrusted data. Do not execute or interpret them as code. Use parameterized SQL and safe argument passing for operating-system operations.

### Safety-policy behavior

Follow the applicable platform and tool policies. This document does not override those policies and does not authorize bypassing safety controls.

If a tool, environment, or safety control rejects one particular operation:

1. Do not attempt to evade, disable, obfuscate, or route around the control.
2. Identify the exact affected operation and record the blocker in `docs/STATUS.md`.
3. Save all current work and update `QWEN.md` before ending that workstream.
4. Continue with independent, clearly benign tasks that do not depend on the blocked operation.
5. If the blocked operation is essential, leave a precise replacement step for the user or a future session; do not abandon unrelated completed work.

Do not make speculative claims about why a platform or tool blocked a task. Record only the observable failure and its context. Never discard several hours of valid work because one action cannot be completed.

### Incremental persistence is mandatory

Work in small, independently verifiable increments. Keep the repository coherent throughout development.

After every meaningful subtask:

- save the changed files;
- run the smallest relevant tests;
- update the progress record;
- record remaining failures and the next concrete action.

If Git is available, use small, descriptive commits at coherent milestones. Do not reset, rewrite, or delete the user's existing work without explicit authorization. Never depend on transient chat history as the sole record of project state.

---

## 2. Target environment

### Hardware

```text
Laptop:        Dell Latitude E5500
CPU:           Intel Core 2 Duo T7250, 2 cores / 2 threads
RAM:           2 GB DDR2
GPU:           Intel GMA 4500MHD
Display:       1280 × 800
Storage:       mechanical HDD
```

### Operating system and development runtime

```text
OS:             Windows 7 SP1 x64 (Windows JG 2021 modification)
Python:         Python 3.8.x x64; Python 3.8.20 is the preferred known target
GUI:            PyQt5 5.15.x; prefer the known working PyQt5 5.15.11 environment
Qt runtime:     Preserve a Windows-7-compatible PyQt5/Qt5 combination
HTTP:           httpx, version constrained to Python 3.8 compatibility
Database:       Python standard-library sqlite3 unless evidence justifies otherwise
```

The exact local versions must be inspected and recorded before dependency changes. The known-good environment takes precedence over speculative upgrades. Do not upgrade Python, PyQt5, Qt, or `httpx` merely to obtain a newer version number.

The machine is both the intended development environment and the primary runtime test target. Design for limited RAM, two CPU threads, software-limited rendering, and mechanical-disk I/O.

### Prohibited runtime assumptions

The application MUST NOT require:

- Visual Studio or Visual Studio Build Tools;
- .NET, WPF, WinUI, or MSBuild;
- Python newer than 3.8;
- Node.js, Java, Electron, or an embedded browser engine;
- Windows 10/11-only APIs;
- GitHub Actions or another remote service for normal local execution or testing.

CI may be an optional convenience, but it is not a substitute for local build/run instructions.

---

## 3. Mandatory technology constraints

### Python

Use Python 3.8-compatible syntax and standard-library APIs. Do not use syntax or APIs introduced in later Python versions without an explicit compatible alternative.

### GUI

Use PyQt5 as the default GUI framework because it is already known to run in the user's environment. Do not replace it with PyQt6, PySide6, WPF, Electron, or a web-based frontend. A different toolkit may only be proposed if a reproducible compatibility test demonstrates that the current toolkit cannot satisfy a mandatory requirement; document the evidence before changing direction.

The implementation should use ordinary PyQt widgets and layouts, with a custom dark stylesheet or palette. Avoid unnecessary custom painting and GPU-heavy effects.

### HTTP

All application HTTP/API requests and artwork downloads MUST use `httpx`. Check installed versions and dependency compatibility before pinning a version. Do not silently replace `httpx` with `requests`, `aiohttp`, `urllib`, or another HTTP client for convenience. The standard library may be used for unrelated local filesystem operations.

### Storage

Use SQLite through Python's built-in `sqlite3` module unless testing demonstrates a concrete need for an additional dependency. Keep database files local. Do not store artwork blobs directly in the database without a measured, documented reason.

### Packaging

Evaluate and pin a packaging toolchain compatible with Python 3.8 and the Windows 7 target. PyInstaller is a candidate, not an automatic assumption. Verify the exact version and bootloader/runtime compatibility. Building an executable on a newer Windows host does not by itself prove that the executable runs on Windows 7.

---

## 4. Required first milestone: verify before scaling up

Before implementing the complete product, inspect the environment and execute a small compatibility proof. Do not spend hours constructing the entire application before the GUI can be launched on the target.

The proof-of-concept must include:

1. `python --version` and the exact package versions are recorded.
2. A PyQt5 window opens, renders, resizes, and closes normally.
3. A representative dark palette/stylesheet renders correctly.
4. `sqlite3` can create, write, read, and close a temporary database.
5. `httpx` can perform a bounded HTTPS request against a harmless public endpoint or a controlled test server.
6. A local image can be loaded and rendered through the intended image path.
7. The application can be started through the documented local command.
8. If standalone packaging is part of the release target, a packaged smoke-test build is launched on Windows 7.

Use short timeouts and avoid placing credentials in the proof-of-concept. If the current agent environment cannot run Windows or render a GUI, do not claim these checks passed. Run the checks that are possible, mark the rest `NOT TESTED IN CURRENT ENVIRONMENT`, and create a repeatable smoke-test procedure for the Dell. Do not let an unavailable GUI environment erase the remaining valid work.

**Gate:** substantial UI and feature implementation begins only after the GUI + database + `httpx` stack has passed the available compatibility checks and any untestable checks have an explicit target-machine verification step.

---

## 5. Project records and recovery protocol

Maintain these project records in the repository:

```text
QWEN.md
README.md
CHANGELOG.md
docs/STATUS.md
docs/DECISIONS.md
docs/TEST_REPORT.md
docs/PERFORMANCE_REPORT.md
docs/WINDOWS7_LIVE_TEST.md
```

Create or simplify files as appropriate, but preserve the functions described below.

### `QWEN.md`

Persistent working memory. Keep it concise and current. Record:

- project purpose and hard constraints;
- current stack and verified package versions;
- repository layout;
- exact run/test/build commands;
- current milestone and status;
- important architectural decisions;
- known defects and constraints;
- the next concrete task.

### `docs/STATUS.md`

Track each milestone using one of: `NOT STARTED`, `IN PROGRESS`, `PASS`, `FAIL`, `BLOCKED`, `NOT TESTED`. Each status must include brief evidence or the precise missing evidence.

### `docs/DECISIONS.md`

Record only decisions that materially affect compatibility, performance, data safety, UX, or maintainability. Include alternatives considered and the reason for the decision.

### `docs/TEST_REPORT.md`

Record test command, environment, result, and failures. Distinguish automated tests, local GUI tests, live API tests, and real Windows 7 tests.

### `docs/PERFORMANCE_REPORT.md`

Store actual measurements and measurement conditions. Do not fill missing results with estimates.

### `docs/WINDOWS7_LIVE_TEST.md`

Provide a short repeatable manual test checklist for the target Dell, particularly for tasks unavailable in a non-Windows agent sandbox.

### Checkpoint cadence

Checkpoint after every meaningful phase and after any change that fixes a defect. A checkpoint should include coherent source changes, tests, updated status, and a clear next step. Do not wait until the end of a long implementation session to save the project state.

If the session ends unexpectedly, the next session must be able to resume from the repository records without reconstructing progress from chat history.

---

## 6. User-supplied UI reference: `ui-reference.html`

The user supplied `ui-reference.html`, a static HTML/CSS design reference produced for the earlier Cartridge concept. **Use it as a visual and workflow reference.** The preferred UI concept is explicitly approved by the user.

At the beginning, inspect the file if it is present in the project workspace. Treat it as reference material, not as executable application code. Do not use its placeholder records or sample measurements as real application data. Recreate its visual language and essential workflows in PyQt5; do not attempt to embed the HTML page as the application UI or depend on a browser runtime.

If the HTML file is not present in the repository, use the following design specification as the fallback source of truth.

### 6.1 Visual language

Use a compact, flat dark theme suitable for the GMA 4500MHD and a 1280×800 display. The reference intentionally avoids blur, box shadows, filter effects, and animations. Use borders and flat surfaces to establish hierarchy.

Reference color tokens:

```text
Background:          #14161A
Surface:              #1B1E24
Surface secondary:    #22262E
Surface tertiary:     #2A2F39
Border:               #2E343F
Strong border:        #3C4351
Primary text:         #E8EAED
Secondary text:       #A0A8B4
Muted text:           #6B7280
Accent:               #4EA1FF
Accent darker:        #2C6FBF
Success:              #4ADE80
Warning:              #FBBF24
Error:                #F87171
```

Use Segoe UI when available, with sensible Windows fallbacks. Keep typography restrained, use consistent spacing, and avoid tiny text for essential controls. Borders should generally be 1 px. Rounded corners may be subtle (approximately 6 px; 10 px for larger cards/dialogs). No animation or transition is required.

These colors are design guidance, not a requirement to reproduce CSS pixel-for-pixel. The actual PyQt UI must remain legible and functional.

### 6.2 Main window composition

The reference uses:

- a compact title bar with app identity and current root path;
- a left navigation rail;
- a filter/sidebar column for search and facets;
- a main collection area;
- a game details pane;
- a bottom status bar.

Adapt widths to PyQt layouts rather than hard-coding one inflexible pixel geometry. The app must remain usable at 1280×800; it may adapt the detail pane or filter column when space is constrained.

### 6.3 Collection Browser

The browser concept contains:

- Collection, Manager, Favourites, Rescan, Settings, and Diagnostics navigation;
- search across game titles and relevant metadata;
- filters such as genre, content type, decade, and collection state;
- sort selection and grid/list view switch;
- game cards with local cover, title, release year, score when available, developer, and content badges;
- a details pane with cover/background, title, release details, genres/tags, franchise, alternative names, age rating where available, folder path, folder size if measured, provider attribution, description, and a small set of screenshots;
- actions for Open folder, Edit, and Favourite;
- visible missing-artwork or missing-folder state;
- a small status bar with result count and keyboard hints.

The reference mock-up shows a five-column cover grid beside a detail pane. Implement a responsive equivalent; do not require five columns at every window size.

### 6.4 Manager

The manager concept provides a table of discovered folders and their state. Useful columns include:

- physical folder;
- associated title;
- association/status;
- artwork status;
- user-defined content types;
- last verification time or a suitable status.

Provide practical views or filters for:

- Needs attention;
- Missing artwork;
- Missing folders;
- All entries;
- Root folders;
- Content types.

The UI must distinguish unmatched folders, incomplete records, missing artwork, missing directories, and unavailable drives. Do not collapse these into one ambiguous error state.

### 6.5 Add-game dialog

Use the reference's compact import workflow:

1. choose or confirm a discovered folder;
2. show a brief scan summary and suggested content types;
3. enter or edit a game title query;
4. search IGDB;
5. show ranked results with title, release year, useful metadata, provider label, and thumbnail when available;
6. permit the user to select a result;
7. allow custom content types;
8. offer artwork choices, including cover and a modest number of screenshots;
9. optionally offer a folder-size scan if it may be slow;
10. provide **Enter details manually** when no suitable API result exists;
11. show a clear final import action.

Do not silently import a low-confidence match. Show loading/error/empty states and keep the dialog responsive during network operations.

### 6.6 Settings

Provide settings for:

- one or more root game folders;
- IGDB client ID and secret;
- RAWG API key;
- API connectivity/status;
- cache or diagnostic options if appropriate.

Credential fields MUST be masked. No secret value may appear in logs, diagnostics, crash reports, README, screenshots, or exported reports.

### 6.7 Diagnostics

Provide a lightweight diagnostics view/report with actual available measurements, such as:

- application and package versions;
- database path and integrity status;
- startup timing if instrumented;
- current process working set where reliably measurable;
- image-cache statistics if implemented;
- recent operation latency samples;
- API connectivity state without credential values;
- collection counts and error counts.

Diagnostics exports MUST omit API credentials, tokens, full private paths, game titles, or any other user-specific information unless the user explicitly selects a local export format that clearly warns about such content. The default shareable report should be sanitized. Never display fabricated sample measurements as current measurements.

---

## 7. Product behavior and collection model

### Root directory

The user chooses a root directory such as:

```text
E:\Gry\
```

Its child directories represent a game or a logical grouping of games. Begin with a predictable scan policy and document it. Avoid an unbounded recursive scan through every file on every launch.

### Database location

The collection database should live with the selected games root, in an application-managed directory, for example:

```text
E:\Gry\.cartridge\collection.db
```

The agent may choose a clearer name, but the database should be associated with the selected root folder rather than silently living beside the executable. Configure the root and database path visibly. Ensure the application-managed database/cache directories are excluded from game discovery.

If the selected root cannot be written, explain this clearly and offer an explicit alternative location; never silently write to an unexpected path. Database location must be visible in Settings or Diagnostics.

### Game identity

A game record must have a robust association with its physical folder. Avoid duplicate records for the same normalized folder path. Account for Windows path case-insensitivity and path separators. Handle missing, moved, renamed, inaccessible, and temporarily unavailable folders without crashing or deleting metadata.

### Filesystem safety

The application MUST NOT move, rename, delete, or rewrite game files as part of scanning or importing. It may create an application-managed artwork/cache directory inside the selected game folder, and it may create its database directory under the configured root. Explain those writes to the user and keep them limited to application-owned paths.

Opening a folder must use a Windows-compatible method and validate that the target exists. Do not execute discovered files automatically.

---

## 8. SQLite and persistence requirements

Use SQLite for structured, persistent local data. Design the schema around real query and edit flows rather than normalizing every conceivable provider field.

The model will likely need records for:

- games and their physical folder paths;
- provider identifiers and source attribution;
- titles, aliases, descriptions and release data;
- developers/publishers where useful;
- genres, platforms, franchises/series where useful;
- user-defined content types/tags;
- favourite/user state;
- artwork asset references;
- application settings and root folders;
- user-edited overrides when needed.

Requirements:

- parameterized SQL only;
- suitable uniqueness constraints and indexes;
- foreign-key enforcement where used;
- schema versioning and migrations;
- explicit transaction boundaries for imports and edits;
- predictable connection lifecycle;
- database integrity check available through Diagnostics or tests;
- backup/export guidance for the collection database.

Do not silently overwrite user-authored titles, notes, favourites, tags, or overrides during a provider refresh. Keep provider-derived fields distinguishable from user-edited values where necessary.

A failed import must leave the database consistent. Avoid records that appear complete when their asset download or metadata persistence failed; use an explicit incomplete/error state if partial persistence is the most useful recovery strategy.

---

## 9. Filesystem scan and custom content types

The Manager should discover immediate game folders under each configured root and identify whether each folder is already represented in the catalogue.

It may inspect filenames and limited directory structure to suggest tags. Examples of neutral indicators include `.exe`, `.iso`, installer files, `goggame-*.info`, DOSBox-related files, manuals, and patch folders. Detection is advisory only and must not run any discovered program.

Content types are user-defined data, not a hard-coded enum. Initial suggestions may include:

```text
GOG, EXE, ISO, Installer, Portable, Emulator, Patch, Backup, Manual, Launcher
```

The user must be able to add, rename, and remove types without changing application code. Avoid duplicating tags that differ only by whitespace/case unless the product intentionally allows that distinction.

Folder-size measurement may be optional or user-triggered because a deep scan can be expensive on a mechanical HDD. Report when the value was measured; do not present an estimate as an exact value.

---

## 10. Metadata providers and `httpx`

### Providers

- Primary: IGDB, using the required Twitch OAuth2 flow.
- Fallback: RAWG.
- Manual metadata entry must always be available.

The local catalogue must not depend on either service after metadata/artwork has been imported.

### `httpx` requirements

Use `httpx` for all API requests and artwork downloads. Pin a Python-3.8-compatible version after checking the current local environment. Use explicit connect/read/write/pool timeouts suitable for a desktop application. Handle timeouts, DNS errors, TLS errors, non-success status codes, malformed JSON, rate limits, and incomplete responses.

Do not block the Qt event loop during requests or downloads. Use a Qt-compatible background-task design (for example, a bounded worker pool) rather than creating unlimited threads/tasks. Return results to the GUI through safe signals/slots or an equivalent toolkit-compatible mechanism.

Do not add concurrent requests unless they improve user-visible latency and remain bounded. Respect provider rate limits. Retry only appropriate transient errors, with a finite retry count and clear user-visible failure state.

### Search result quality

Provider ordering may not match the user's intended title. Apply local ranking when useful, considering normalized title, exact title match, punctuation, diacritics, alternative titles, year, and platform. Display provider attribution and useful disambiguating information. Never auto-associate a weak match without user confirmation.

### Live tests

Live provider tests must be opt-in and must not make the normal test suite depend on credentials or internet access. Verify actual authentication/search/detail/artwork flows only when explicitly enabled. Keep recorded fixture payloads sanitized and free of secrets.

---

## 11. Artwork storage and memory discipline

Store downloaded artwork locally under the associated game folder, for example:

```text
<game-folder>\_cartridge\assets\
```

Use a consistent asset naming scheme. Content hashes may be used for integrity checking and duplicate detection. Do not store the original URL as the only image reference; local browsing must work offline.

Requirements:

- validate download status, size, and image format before accepting an asset;
- write downloads to a temporary file and finalize only after validation;
- tolerate interrupted/truncated downloads;
- provide placeholders for absent/corrupt images;
- generate or load display-sized thumbnails where appropriate;
- avoid decoding full-resolution screenshots for small cards;
- use lazy loading where beneficial;
- bound the in-memory image cache;
- avoid repeated decoding during scrolling;
- never crash the browser because a single image is invalid.

Keep user game files untouched. Only write artwork and manifests to application-managed asset paths. Manifests, if used, must contain no credentials.

---

## 12. Collection browser requirements

The everyday browser must be the visually strongest part of the product while staying efficient on the target hardware.

It must provide:

- collection overview;
- cover grid and/or compact list view;
- title search;
- useful filters;
- useful sorting;
- a selected-game details view;
- clear missing-data states;
- an Open folder action;
- editing and favourites if implemented in the data model;
- local artwork and metadata without network access.

Search should include useful fields such as title, alternative title, summary, developer/publisher, franchise, and content types. It should be case-insensitive and tolerant of punctuation and diacritics when practical.

Filters should prioritize useful facets: genre, content type, year/decade, developer/publisher, favourite, incomplete metadata, missing artwork, and missing folders where those fields exist. Sort options should include title and other populated metadata such as release year, rating, date added, or developer. Unknown values must be handled consistently.

The UI must not freeze on a larger local collection. Avoid rebuilding every card for each keystroke if an incremental model/filter is appropriate. A collection with at least 1,000 lightweight database records should remain practical to browse; measure actual target behavior rather than promising a fixed latency without evidence.

---

## 13. Manager requirements

The Manager must make the collection's state transparent. It should let the user:

- inspect discovered folders;
- identify unmatched folders;
- add a game through API search;
- create a record manually;
- edit metadata;
- edit content types;
- refresh metadata explicitly;
- rescan configured roots;
- detect missing folders and unavailable drives;
- identify records without artwork or with incomplete metadata;
- open a selected folder;
- re-associate a record with a folder after a user-confirmed move.

Do not automatically delete database records when folders disappear. Preserve metadata and mark the filesystem state. Distinguish an absent folder from an unavailable drive.

---

## 14. Responsive GUI and target resolution

Design for **1280×800 first**. Use Qt layouts and size policies rather than rigid absolute positioning. Essential actions must remain visible. Dialogs must fit the display and remain operable when resized.

Long-running work—API requests, downloads, folder scans, and larger database operations—must not block the GUI thread. Provide visible progress or an explicit busy state for operations that take noticeable time, and handle failure/cancellation without leaving controls permanently disabled.

Use keyboard navigation and sensible shortcuts where practical. Consider `Ctrl+F` for search, `Enter` for the selected folder/action, `F5` for rescan, and `Esc` to clear/cancel, but do not assign a shortcut that conflicts with a more important platform behavior.

---

## 15. Secrets and configuration

Temporary development API credentials may be supplied separately. Treat them as secrets. Do not ask to place actual values in source files or the prompt document.

Secrets MUST NOT appear in:

- source code;
- `README.md` or any documentation;
- tests or fixtures;
- SQLite records;
- logs or tracebacks;
- screenshots;
- diagnostics exports;
- commit messages;
- Git history;
- PyInstaller bundles or other release artifacts.

For application-user credentials, support entry through Settings. Prefer a Windows-appropriate protected storage mechanism if it is compatible with Python 3.8/Windows 7 and can be tested. If secure persistent storage cannot be verified, prefer a clearly documented session-only option or a user-controlled local environment file that is excluded from Git; do not invent security guarantees.

All credential fields must be masked. Diagnostics and error handling must never print raw request headers, access tokens, client secrets, or API keys. The release process must include a secret scan of tracked files and generated artifacts. A Git-history scan should be used when Git history exists.

If a credential is accidentally exposed, stop distributing the affected artifact, remove it from the release/repository as appropriate, and tell the user to revoke/rotate the credential. Do not repeat the secret in the report.

---

## 16. Automated testing

Build a test suite around deterministic local behavior. The default test suite must not need live API credentials or internet access.

At minimum, cover:

- path normalization and duplicate-folder handling;
- title normalization and search ranking;
- SQLite creation, migrations, constraints, and repository operations;
- folder discovery and application-managed-directory exclusion;
- content-type detection;
- safe metadata mapping from fixture responses;
- malformed and incomplete API payload handling;
- timeout, rate-limit, and provider-error handling;
- artwork validation, partial download recovery, and cache behavior;
- import rollback/recovery;
- user override preservation during metadata refresh;
- filtering/sorting behavior;
- missing-folder and unavailable-drive state;
- credential redaction;
- offline browsing from local database and assets.

Use a fake HTTP transport or local fixture server for repeatable `httpx` tests. Tests must not use real secrets. Avoid fragile tests that require a third-party service to be online.

---

## 17. GUI verification and honest test status

Actually launch the application and interact with it wherever the current environment permits. Verify navigation, layouts, dialogs, search, filters, sorting, image loading, manual import, API import when enabled, opening folders, and error states.

The following are distinct statuses and must never be conflated:

- `PASS`: executed in the stated environment and evidence recorded;
- `FAIL`: executed and failed, with reproducible details;
- `NOT TESTED`: not executed;
- `BLOCKED`: execution was attempted but a specific environmental restriction prevented it.

Parsing UI code, importing modules, or passing unit tests does not count as a live GUI test. A Linux or headless sandbox does not count as a Windows 7 test. Never invent a screenshot, a click-through result, a memory number, or a successful API exchange.

If the agent cannot run the real GUI on Windows 7, continue implementation and portable tests, then create an actionable `docs/WINDOWS7_LIVE_TEST.md` checklist and clearly list the target tests as `NOT TESTED`. The project must remain in a recoverable state and must not be discarded merely because the agent's own sandbox lacks Windows.

---

## 18. Performance measurement

Measure on the real Dell whenever possible. Record the environment for each number, including Python/toolkit versions, number of game records, artwork conditions, and whether the measurement came from the Dell or another machine.

Measure at minimum:

- cold startup;
- warm startup;
- idle working set;
- browsing working set;
- peak working set while viewing artwork;
- idle CPU;
- search and filter latency;
- sorting latency;
- folder scan time;
- image load/thumbnail latency;
- database query latency;
- API latency separately from local processing.

Do not claim measurements taken on a modern CI runner describe the E5500. Do not fabricate targets or results. Establish reasonable budgets after baseline measurements, then optimize measured bottlenecks.

Optimization loop:

```text
measure baseline
→ identify a reproducible bottleneck
→ implement one focused change
→ run targeted tests
→ measure again under comparable conditions
→ keep or revert the change
→ run regression tests
→ checkpoint
```

Avoid unbounded caches, unnecessary polling, repeated deep scans, redundant requests, and uncontrolled worker/thread creation.

---

## 19. Local development, commands, and packaging

The repository must be usable locally without Visual Studio or a remote build system.

Provide a concise `requirements.txt` or equivalent pinned/compatible dependency definition, plus exact commands for:

- creating a virtual environment;
- installing dependencies;
- launching the application;
- running automated tests;
- running opt-in live API tests;
- packaging the application;
- running the packaged result.

Use only commands verified in the available environment. If a command is Windows-specific, label it as such. Prefer a single predictable entry point for running and testing the application.

Packaging should produce a self-contained folder or executable if that is feasible and verified for the target. Preserve a source-run workflow even if executable packaging needs separate work. Do not require the user to install Visual Studio, .NET, Node.js, Java, or a browser runtime.

GitHub Actions may provide optional CI and artifacts, but the Dell must be able to run the source and execute the test suite using the documented local Python environment.

---

## 20. Repository and open-source delivery

Prepare the project for GitHub with an MIT license and accurate documentation. Expected deliverables include:

```text
README.md
LICENSE
requirements.txt
QWEN.md
source package
unit/integration tests
docs/STATUS.md
docs/DECISIONS.md
docs/TEST_REPORT.md
docs/PERFORMANCE_REPORT.md
docs/WINDOWS7_LIVE_TEST.md
```

The README should explain:

- application purpose and key features;
- supported environment and unverified limitations;
- first-time setup and run instructions;
- test commands;
- packaging instructions;
- IGDB/Twitch and RAWG configuration;
- where the database and artwork are stored;
- credential-handling behavior;
- screenshots derived from the actual running app, when available;
- known limitations and license.

Do not claim compatibility or features that have not been verified. Do not use fake screenshots or treat the `ui-reference.html` mock-up as a screenshot of the finished application.

---

## 21. Implementation sequence and required checkpoints

Follow this sequence unless a recorded technical reason requires a different order. Do not skip compatibility validation.

### M0 — Inspect

- Inspect the repository and current environment.
- Inspect `ui-reference.html` if present.
- Identify existing source and user changes; do not destroy them.
- Record Python, PyQt5, Qt, `httpx`, and packaging versions.
- Create/update `QWEN.md` and `docs/STATUS.md`.

### M1 — Compatibility proof

- Build and run the small PyQt5/SQLite/`httpx` proof-of-concept.
- Record exact results and untestable target-specific items.
- Do not proceed on an unresolved fundamental incompatibility.

### M2 — Application shell and persistent settings

- Main window, navigation, dark palette, root-folder setup, settings storage.
- Test startup and geometry at 1280×800.

### M3 — SQLite model

- Schema, repository, migrations, transactions, tests.

### M4 — Filesystem discovery

- Root folder scanning, status classification, custom-tag suggestions, tests.

### M5 — Metadata providers

- `httpx` infrastructure, IGDB, RAWG fallback, manual editing, fixtures, opt-in live tests.

### M6 — Artwork pipeline

- Safe downloads, local storage, validation, thumbnail/cache rules, tests.

### M7 — Game Manager

- Entries table, attention states, add/import/edit workflows.

### M8 — Collection Browser

- Search, filters, sorting, cards/list, details pane, local artwork.

### M9 — Failure and offline states

- Offline launch, provider failure, missing folder, invalid image, interrupted import.

### M10 — Diagnostics and performance

- Sanitized diagnostics and actual measurements.

### M11 — Packaging and local workflow

- Verify local commands and packaged startup where possible.

### M12 — Real Windows 7 live verification

- Execute the target checklist on the Dell or accurately mark items still untested.

### M13 — Regression and release preparation

- Full test suite, secret audit, README, MIT license, known limitations, final checkpoint.

At each milestone, record: changed files, tests run, evidence, open defects, current status, and next action.

---

## 22. Definition of Done

A feature is complete only when all applicable conditions are true:

```text
implemented
AND runs in its intended environment
AND automated tests pass where applicable
AND failure modes are handled
AND live behavior is verified where applicable
AND performance is measured where relevant
AND regression checks pass
AND documentation reflects the actual state
```

The whole project is release-ready only when:

- the core workflow is implemented;
- local data persists and survives restart;
- GUI is usable at 1280×800;
- the actual GUI has been launched and interacted with in a real compatible Windows environment, or its status is explicitly reported as untested with a repeatable checklist;
- IGDB and RAWG work in opt-in live tests when credentials are available;
- offline collection browsing works;
- artwork is stored locally and cached safely;
- folder operations are safe;
- tests pass;
- secrets are absent from tracked files and artifacts;
- setup, run, test, and packaging commands are documented;
- known limitations are disclosed.

Never mark an untested requirement as `PASS` just to satisfy the release gate. If a test is blocked by the current environment, preserve the project, deliver the work that can be verified, and leave a precise follow-up step for the real target machine.

---

## 23. Final engineering report

At the end of each development session, report briefly:

1. **Changed:** concrete files/features implemented.
2. **Verified:** exact tests or runtime actions performed and their results.
3. **Failed/blocked:** reproducible failures and environmental blockers.
4. **Remaining:** the highest-priority incomplete work.
5. **Next action:** one concrete step.

At project completion, provide this evidence-based summary:

```text
PROJECT NAME:
Python version:
PyQt5 version:
Qt runtime version:
httpx version:
SQLite implementation:
Packaging tool/version:

Windows 7 live test: PASS / FAIL / NOT TESTED / BLOCKED
GUI at 1280×800: PASS / FAIL / NOT TESTED / BLOCKED
SQLite persistence: PASS / FAIL
IGDB live test: PASS / FAIL / NOT TESTED
RAWG live test: PASS / FAIL / NOT TESTED
Artwork pipeline: PASS / FAIL
Filesystem handling: PASS / FAIL
Search/filter/sort: PASS / FAIL
Offline mode: PASS / FAIL
Automated tests: PASS / FAIL
Secret audit: PASS / FAIL

Cold start:
Idle RAM:
Browsing RAM:
Peak RAM:
Search/filter latency:
Folder scan time:

Known limitations:
Release status:
```

Use measured values only. If a measurement has not been collected, write `NOT MEASURED`.

---

## 24. Final operating principle

The user's reference concept is approved: preserve its overall product identity and workflow, but implement it as a real PyQt5 desktop application—not as HTML embedded in a browser and not as a port of the old WPF/.NET implementation.

The fixed technical baseline is:

**Python 3.8.x + PyQt5 + `httpx` + SQLite + Windows 7 SP1 x64.**

First prove that the stack runs. Then build in small, testable increments. Persist progress continuously. Measure rather than guess. Do not bypass safety controls. If one operation is blocked, checkpoint the work and continue with independent safe tasks. Never claim a test passed without evidence.

**PROVE THE FOUNDATION → IMPLEMENT IN CHECKPOINTS → TEST → MEASURE → PACKAGE → VERIFY ON THE TARGET.**
