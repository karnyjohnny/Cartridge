"""Domain models.

Plain dataclasses with no Qt and no I/O, so every layer (repository, providers,
filtering, UI) can be tested without a GUI or a database connection.

Two rules shape these types:

* **provider data and user edits never share a field.** ``title`` is what the
  provider said; ``user_title`` is what the user typed. The effective value is
  ``user_title or title`` (see :meth:`Game.effective_title`). A provider refresh
  writes only the provider columns, so it can never destroy user input.
* **absence is distinct from failure.** ``folder_size_bytes=None`` means "never
  measured", not "zero bytes"; ``folder_state`` says whether the folder is gone,
  or whether the whole drive is unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from cartridge.paths import FolderState

PROVIDER_IGDB = "igdb"
PROVIDER_RAWG = "rawg"
PROVIDER_MANUAL = "manual"

ASSET_COVER = "cover"
ASSET_SCREENSHOT = "screenshot"
ASSET_BACKGROUND = "background"
ASSET_LOGO = "logo"

# metadata_state values
STATE_NONE = "none"          # folder known, no metadata yet
STATE_PARTIAL = "partial"    # some fields populated
STATE_COMPLETE = "complete"  # provider match applied
STATE_MANUAL = "manual"      # entered by hand, no provider
STATE_ERROR = "error"        # last refresh failed; metadata_error explains


@dataclass
class Asset(object):
    """One local artwork file belonging to a game."""

    kind: str = ASSET_COVER
    rel_path: str = ""                 # relative to the game folder
    source_url: Optional[str] = None   # attribution only - never the sole reference
    provider: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    size_bytes: Optional[int] = None
    sha256: Optional[str] = None
    sort_order: int = 0
    state: str = "ok"                  # ok | pending | missing | corrupt
    downloaded_at: Optional[str] = None
    id: Optional[int] = None
    game_id: Optional[int] = None

    def is_usable(self) -> bool:
        return self.state == "ok" and bool(self.rel_path)


@dataclass
class Game(object):
    """A catalogued game and the folder it lives in."""

    folder_path: str = ""
    folder_key: str = ""
    title: str = ""
    id: Optional[int] = None
    root_id: Optional[int] = None

    # --- provider-supplied metadata -------------------------------------
    sort_title: str = ""
    summary: Optional[str] = None
    release_date: Optional[str] = None
    release_year: Optional[int] = None
    rating: Optional[float] = None
    age_rating: Optional[str] = None
    franchise: Optional[str] = None
    developer: Optional[str] = None
    publisher: Optional[str] = None
    genres: List[str] = field(default_factory=list)
    platforms: List[str] = field(default_factory=list)
    alternative_names: List[str] = field(default_factory=list)

    # --- user overrides (never written by a provider refresh) ------------
    user_title: Optional[str] = None
    user_summary: Optional[str] = None
    user_release_year: Optional[int] = None
    user_rating: Optional[float] = None
    user_developer: Optional[str] = None
    user_publisher: Optional[str] = None
    user_franchise: Optional[str] = None
    user_age_rating: Optional[str] = None
    user_genres: List[str] = field(default_factory=list)

    # --- user state ------------------------------------------------------
    favourite: bool = False
    notes: Optional[str] = None
    content_types: List[str] = field(default_factory=list)
    suggested_types: List[str] = field(default_factory=list)

    # --- provenance ------------------------------------------------------
    provider: Optional[str] = None
    provider_id: Optional[str] = None
    provider_url: Optional[str] = None
    metadata_state: str = STATE_NONE
    metadata_error: Optional[str] = None

    # --- filesystem ------------------------------------------------------
    folder_state: str = FolderState.UNKNOWN.value
    folder_state_checked_at: Optional[str] = None
    folder_size_bytes: Optional[int] = None
    folder_size_measured_at: Optional[str] = None

    # --- artwork ---------------------------------------------------------
    assets: List[Asset] = field(default_factory=list)

    # --- bookkeeping -----------------------------------------------------
    added_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_verified_at: Optional[str] = None
    last_refreshed_at: Optional[str] = None

    # ------------------------------------------------------------------
    def effective_title(self) -> str:
        return self.user_title or self.title or self.folder_basename()

    def effective_summary(self) -> Optional[str]:
        return self.user_summary if self.user_summary is not None else self.summary

    def effective_year(self) -> Optional[int]:
        return self.user_release_year if self.user_release_year is not None else self.release_year

    def effective_rating(self) -> Optional[float]:
        return self.user_rating if self.user_rating is not None else self.rating

    def effective_developer(self) -> Optional[str]:
        return self.user_developer if self.user_developer is not None else self.developer

    def effective_publisher(self) -> Optional[str]:
        return self.user_publisher if self.user_publisher is not None else self.publisher

    def effective_franchise(self) -> Optional[str]:
        return self.user_franchise if self.user_franchise is not None else self.franchise

    def effective_age_rating(self) -> Optional[str]:
        return self.user_age_rating if self.user_age_rating is not None else self.age_rating

    def effective_genres(self) -> List[str]:
        return list(self.user_genres) if self.user_genres else list(self.genres)

    def has_user_overrides(self) -> bool:
        return any(
            value is not None
            for value in (
                self.user_title, self.user_summary, self.user_release_year,
                self.user_rating, self.user_developer, self.user_publisher,
                self.user_franchise, self.user_age_rating,
            )
        ) or bool(self.user_genres)

    def folder_basename(self) -> str:
        from cartridge.paths import folder_name

        return folder_name(self.folder_path) or self.folder_path

    def cover(self) -> Optional[Asset]:
        for asset in self.assets:
            if asset.kind == ASSET_COVER and asset.is_usable():
                return asset
        return None

    def screenshots(self) -> List[Asset]:
        return sorted(
            (a for a in self.assets if a.kind == ASSET_SCREENSHOT and a.is_usable()),
            key=lambda a: (a.sort_order, a.rel_path),
        )

    def artwork_state(self) -> str:
        """``ok`` | ``partial`` | ``missing`` - shown in the Manager."""
        cover = self.cover()
        shots = self.screenshots()
        if cover and shots:
            return "ok"
        if cover or shots:
            return "partial"
        return "missing"

    def is_folder_usable(self) -> bool:
        return self.folder_state == FolderState.PRESENT.value

    def attention_reasons(self) -> List[str]:
        """Why the Manager flags this entry (empty list means no attention)."""
        reasons = []
        if self.folder_state == FolderState.MISSING.value:
            reasons.append("folder missing")
        elif self.folder_state == FolderState.UNAVAILABLE_DRIVE.value:
            reasons.append("drive unavailable")
        elif self.folder_state == FolderState.ACCESS_DENIED.value:
            reasons.append("folder not accessible")
        if self.metadata_state in (STATE_NONE, STATE_ERROR):
            reasons.append("incomplete metadata")
        if self.artwork_state() == "missing":
            reasons.append("no artwork")
        return reasons

    def needs_attention(self) -> bool:
        return bool(self.attention_reasons())


@dataclass
class Root(object):
    """A configured collection root directory."""

    path: str
    path_key: str = ""
    id: Optional[int] = None
    label: Optional[str] = None
    enabled: bool = True
    added_at: Optional[str] = None
    last_scanned_at: Optional[str] = None


@dataclass
class ContentType(object):
    """A user-defined content type (GOG, ISO, Installer, ...). Not an enum."""

    name: str
    id: Optional[int] = None
    name_key: str = ""
    color: Optional[str] = None
    sort_order: int = 0
    created_at: Optional[str] = None
    game_count: int = 0


@dataclass
class FolderEntry(object):
    """One Manager row: a discovered folder and how it relates to the catalogue."""

    path: str
    name: str
    key: str = ""
    state: str = FolderState.UNKNOWN.value
    game_id: Optional[int] = None
    game_title: Optional[str] = None
    association: str = "unmatched"     # matched | unmatched | db_only
    artwork_state: str = "missing"
    metadata_state: str = STATE_NONE
    content_types: List[str] = field(default_factory=list)
    suggested_types: List[str] = field(default_factory=list)
    last_verified_at: Optional[str] = None
    size_bytes: Optional[int] = None
    size_measured_at: Optional[str] = None
    root_path: Optional[str] = None

    def needs_attention(self) -> bool:
        if self.association == "unmatched":
            return True
        if self.state != FolderState.PRESENT.value:
            return True
        if self.artwork_state == "missing":
            return True
        return self.metadata_state in (STATE_NONE, STATE_ERROR)


@dataclass
class ProviderGame(object):
    """A normalized search/detail result from any provider."""

    provider: str
    provider_id: str
    title: str
    year: Optional[int] = None
    release_date: Optional[str] = None
    summary: Optional[str] = None
    cover_url: Optional[str] = None
    screenshot_urls: List[str] = field(default_factory=list)
    background_url: Optional[str] = None
    logo_url: Optional[str] = None
    genres: List[str] = field(default_factory=list)
    platforms: List[str] = field(default_factory=list)
    developer: Optional[str] = None
    publisher: Optional[str] = None
    franchise: Optional[str] = None
    alternative_names: List[str] = field(default_factory=list)
    rating: Optional[float] = None
    age_rating: Optional[str] = None
    url: Optional[str] = None
    match_score: float = 0.0
    raw: Optional[Dict[str, Any]] = None   # kept for debugging; never logged

    def to_manual_game(self) -> Dict[str, Any]:
        """Provider-neutral dict consumed by the repository on import."""
        return {
            "title": self.title,
            "summary": self.summary,
            "release_date": self.release_date,
            "release_year": self.year,
            "rating": self.rating,
            "age_rating": self.age_rating,
            "franchise": self.franchise,
            "developer": self.developer,
            "publisher": self.publisher,
            "genres": list(self.genres),
            "platforms": list(self.platforms),
            "alternative_names": list(self.alternative_names),
            "provider": self.provider,
            "provider_id": self.provider_id,
            "provider_url": self.url,
        }


@dataclass
class ScanSummary(object):
    """Result of a root scan."""

    root_path: str = ""
    folders_seen: int = 0
    new_folders: int = 0
    matched: int = 0
    unmatched: int = 0
    missing_folders: int = 0
    unavailable_drives: int = 0
    app_managed_skipped: int = 0
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    duration_ms: float = 0.0
    errors: List[str] = field(default_factory=list)

    def as_text(self) -> str:
        return (
            "%d folders seen · %d new · %d matched · %d unmatched · "
            "%d missing · %d drives unavailable"
            % (
                self.folders_seen, self.new_folders, self.matched, self.unmatched,
                self.missing_folders, self.unavailable_drives,
            )
        )
