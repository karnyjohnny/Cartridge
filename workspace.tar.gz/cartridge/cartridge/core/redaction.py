"""Credential redaction for logs, diagnostics exports and error messages.

Brief section 15 is uncompromising: no secret value may appear in source, docs,
tests, fixtures, SQLite records, logs, tracebacks, screenshots, diagnostics
exports, commit messages, Git history or release artifacts.

Two layers are applied:

1. **Known-value scrubbing** - the application registers the secret values it
   holds (IGDB client secret, RAWG key, Twitch access/refresh tokens) and any
   exact occurrence is replaced. This is the only way to catch a token that was
   interpolated into an arbitrary error string.
2. **Pattern scrubbing** - structural patterns that reveal credentials even when
   the concrete value is unknown (``Authorization: Bearer ...``,
   ``client_secret=...``, ``key=<32 hex>``, long high-entropy assignments).

Redaction is *lossy by design*. Nothing here ever re-derives the original value,
and the module keeps no copy of a secret beyond the in-memory set needed for
matching.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

REDACTED = "***REDACTED***"

# Structural patterns. Order matters: the most specific first.
_PATTERNS: List[re.Pattern] = [
    # Bearer tokens FIRST. If the generic header pattern ran first it would
    # consume only "Authorization: Bearer" (its value is \S+) and leave the
    # token itself behind in the output.
    re.compile(r"(?i)\bbearer\s+[a-z0-9\-_\.=]{8,}"),
    # HTTP headers
    re.compile(r"(?i)\b(authorization|proxy-authorization|x-api-key|client-id|"
               r"client-secret|access-token|refresh-token|api-key)\s*[:=]\s*\S+"),
    # OAuth / query-string credentials
    re.compile(r"(?i)\b(client_secret|client_id|api_?key|apikey|secret|token|"
               r"access_token|refresh_token|password|passwd|pwd)\s*[=:]\s*[^\s&;,\}\]\)]+"),
    # Twitch/IGDB style 30-char base-32 client ids and 30+ char secrets
    re.compile(r"\b[a-z0-9]{30,}\b"),
    # RAWG style 32-char hex keys
    re.compile(r"\b[0-9a-f]{32,}\b"),
    # Generic long high-entropy blobs
    re.compile(r"\b[A-Za-z0-9_\-\.]{40,}\b"),
]

# Header names that must always be dropped from any exported header mapping.
SENSITIVE_HEADERS = frozenset(
    h.lower()
    for h in (
        "authorization",
        "proxy-authorization",
        "client-id",
        "client-secret",
        "x-api-key",
        "api-key",
        "access-token",
        "refresh-token",
        "cookie",
        "set-cookie",
    )
)


class Redactor(object):
    """Scrubs secret material out of strings and mappings.

    Thread-safe enough for this app's use (registration happens at startup and
    after a settings change; matching is read-only). Values are stored only as
    lengths + a set of the literal strings, which is unavoidable for exact
    matching, and are never written back out.
    """

    def __init__(self, known: Optional[Iterable[str]] = None, min_len: int = 6):
        self._known = set()
        self._min_len = max(4, int(min_len))
        if known:
            for value in known:
                self.register(value)

    # -- registration ------------------------------------------------------
    def register(self, value: Optional[str]) -> None:
        """Remember a secret value so exact occurrences can be scrubbed."""
        if not value:
            return
        text = str(value).strip()
        if len(text) >= self._min_len:
            self._known.add(text)

    def register_many(self, values: Iterable[Optional[str]]) -> None:
        for value in values or ():
            self.register(value)

    def forget(self, value: Optional[str]) -> None:
        if value and str(value).strip() in self._known:
            self._known.discard(str(value).strip())

    @property
    def known_count(self) -> int:
        return len(self._known)

    # -- scrubbing ---------------------------------------------------------
    def text(self, value: Any) -> str:
        """Return ``value`` as a string with every secret occurrence removed."""
        if value is None:
            return ""
        out = value if isinstance(value, str) else str(value)
        # Longest first so overlapping values cannot leave a fragment behind.
        for secret in sorted(self._known, key=len, reverse=True):
            if secret and secret in out:
                out = out.replace(secret, REDACTED)
        for pattern in _PATTERNS:
            out = pattern.sub(_mask_match, out)
        # Repeat until stable: masking one construct can expose another
        # (e.g. "Authorization: Bearer x" -> "Authorization: ***REDACTED***").
        for _ in range(2):
            previous = out
            for pattern in _PATTERNS:
                out = pattern.sub(_mask_match, out)
            if out == previous:
                break
        return out

    def mapping(self, data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Scrub a header/param mapping, dropping sensitive keys entirely."""
        if not data:
            return {}
        clean: Dict[str, Any] = {}
        for key, value in data.items():
            if str(key).lower() in SENSITIVE_HEADERS:
                clean[key] = REDACTED
                continue
            clean[key] = self.text(value)
        return clean

    def url(self, value: Optional[str]) -> str:
        """Scrub a URL, keeping the host+path but masking credential params."""
        if not value:
            return ""
        text = str(value)
        for secret in sorted(self._known, key=len, reverse=True):
            if secret and secret in text:
                text = text.replace(secret, REDACTED)

        def _mask_param(match):
            name = match.group(1)
            if name.lower() in ("key", "api_key", "apikey", "token", "secret",
                                "client_id", "client_secret", "access_token"):
                return "%s=%s" % (name, REDACTED)
            return match.group(0)

        return re.sub(r"([A-Za-z0-9_\-]+)=([^&#\s]+)", _mask_param, text)

    def exception(self, exc: BaseException) -> str:
        """One-line, redacted description of an exception (never a traceback)."""
        return self.text("%s: %s" % (type(exc).__name__, exc))


def _mask_match(match: "re.Match") -> str:
    """Replace the credential-bearing part of a structural match."""
    raw = match.group(0)
    # Keep the auth scheme readable: "Bearer ***REDACTED***"
    if raw.lower().startswith("bearer "):
        return "Bearer " + REDACTED
    if ":" in raw or "=" in raw:
        index = raw.find(":")
        eq = raw.find("=")
        if index == -1 or (eq != -1 and eq < index):
            index = eq
        head = raw[: index + 1]
        # preserve a single separating space for readability
        if head.endswith(":") and raw[index + 1: index + 2] == " ":
            return head + " " + REDACTED
        return head + REDACTED
    # bare token: keep a short prefix so logs stay diagnosable
    if len(raw) > 12:
        return raw[:4] + REDACTED
    return REDACTED


# Module-level default instance so any part of the app can redact without
# threading an object through every call.
_DEFAULT = Redactor()


def default_redactor() -> Redactor:
    return _DEFAULT


def register_secret(value: Optional[str]) -> None:
    """Register a secret with the process-wide default redactor."""
    _DEFAULT.register(value)


def redact(value: Any) -> str:
    """Scrub ``value`` using the process-wide default redactor."""
    return _DEFAULT.text(value)
