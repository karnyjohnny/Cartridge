"""Time helpers.

All persisted timestamps are ISO-8601 UTC strings with second resolution
(``2026-10-09T14:03:11Z``). Storing text rather than Julian days keeps the
database readable in any SQLite browser, sorts correctly as text, and avoids
local-timezone ambiguity on a machine that may travel.

``now_iso`` is indirected through :func:`set_clock` so tests can freeze time
instead of sleeping or asserting on wall-clock values.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Callable, Optional

_clock: Optional[Callable[[], float]] = None


def set_clock(fn: Optional[Callable[[], float]]) -> None:
    """Install a fake monotonic-free clock for tests (``None`` restores real time)."""
    global _clock
    _clock = fn


def now_iso() -> str:
    """Current UTC time as an ISO-8601 string with second resolution."""
    if _clock is not None:
        return datetime.fromtimestamp(_clock(), tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(value: Optional[str]) -> Optional[datetime]:
    """Parse an ISO-8601 timestamp, tolerating the trailing ``Z``."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def age_text(value: Optional[str], reference: Optional[str] = None) -> str:
    """Human age of a timestamp: ``"just now"``, ``"3 h ago"``, ``"never"``."""
    moment = parse_iso(value)
    if moment is None:
        return "never"
    base = parse_iso(reference) or datetime.now(timezone.utc)
    seconds = max(0, int((base - moment).total_seconds()))
    if seconds < 60:
        return "just now"
    minutes = seconds // 60
    if minutes < 60:
        return "%d min ago" % minutes
    hours = minutes // 60
    if hours < 24:
        return "%d h ago" % hours
    days = hours // 24
    if days < 30:
        return "%d d ago" % days
    return moment.strftime("%Y-%m-%d")


def monotonic() -> float:
    """Monotonic seconds, for latency instrumentation only (never persisted)."""
    return time.monotonic()
