"""Where application credentials live.

Brief section 15 allows three options and forbids inventing guarantees:

1. a Windows-appropriate protected store, **if it can be tested**;
2. otherwise a documented session-only option;
3. or a user-controlled local file excluded from Git.

This module implements all three and, critically, *reports which one is active*
so the Settings screen can tell the truth ("encrypted with Windows DPAPI" versus
"stored unencrypted in a local file — this machine has no protected storage
available").

Backends
--------
``dpapi``
    Windows only. ``CryptProtectData`` / ``CryptUnprotectData`` through
    ``ctypes`` — no third-party dependency, user-scoped, works on Windows 7 and
    Python 3.8. The ciphertext is written to
    ``%APPDATA%\\Cartridge\\secrets.bin``; only the same Windows user on the same
    machine can decrypt it.
``file``
    Plain JSON at ``~/.config/cartridge/credentials.json`` (POSIX) or
    ``%APPDATA%\\Cartridge\\credentials.json`` (Windows when DPAPI is
    unavailable), created with mode ``0600``. **Not encrypted.** The UI says so.
``memory``
    Nothing is persisted. Values come from the environment and die with the
    process. This is the fallback when no writable config directory exists, and
    the mode used by the automated test suite.

Credentials are never written to SQLite (the repository refuses those keys),
never logged (they are registered with the redactor on load), and never included
in a diagnostics export.

Testability note: the DPAPI path cannot be exercised on a non-Windows machine.
It is covered by ``tests/test_secret_store.py`` only through its pure-Python
blob framing, and is marked ``NOT TESTED`` for Windows in
``docs/WINDOWS7_LIVE_TEST.md``.
"""

from __future__ import annotations

import base64
import json
import os
import sys
import threading
from typing import Any, Dict, List, Optional, Tuple

from cartridge.core.redaction import Redactor, default_redactor

DPAPI_BACKEND = "dpapi"
FILE_BACKEND = "file"
MEMORY_BACKEND = "memory"

APP_DIR_NAME = "Cartridge"
CIPHER_FILE_NAME = "secrets.bin"
PLAIN_FILE_NAME = "credentials.json"


def user_config_dir(app_name: str = APP_DIR_NAME) -> str:
    """Per-user configuration directory for the current platform."""
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(
            os.path.expanduser("~"), "AppData", "Roaming"
        )
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(
            os.path.expanduser("~"), ".config"
        )
    return os.path.join(base, app_name)


class SecretStore(object):
    """Read/write credential values through the best available backend."""

    def __init__(
        self,
        directory: Optional[str] = None,
        preferred: Optional[str] = None,
        redactor: Optional[Redactor] = None,
    ):
        self.redactor = redactor or default_redactor()
        self.directory = directory or user_config_dir()
        self._preferred = preferred
        self._lock = threading.RLock()
        self._memory: Dict[str, str] = {}
        self._notes: List[str] = []
        self.backend = self._select_backend()

    # ------------------------------------------------------------------
    def _select_backend(self) -> str:
        if self._preferred == MEMORY_BACKEND:
            self._notes.append("memory backend requested explicitly")
            return MEMORY_BACKEND
        if self._preferred == FILE_BACKEND:
            if self._ensure_dir():
                return FILE_BACKEND
            self._notes.append("config directory is not writable; using memory")
            return MEMORY_BACKEND
        if sys.platform.startswith("win") and self._preferred in (None, DPAPI_BACKEND):
            available, reason = dpapi_available()
            if available:
                if self._ensure_dir():
                    return DPAPI_BACKEND
                self._notes.append("config directory is not writable; using memory")
                return MEMORY_BACKEND
            self._notes.append("DPAPI unavailable (%s)" % reason)
        if self._ensure_dir():
            if self._preferred == DPAPI_BACKEND:
                self._notes.append(
                    "DPAPI requested but not available on this platform; "
                    "falling back to an unencrypted local file"
                )
            return FILE_BACKEND
        self._notes.append("config directory is not writable; using memory")
        return MEMORY_BACKEND

    def _ensure_dir(self) -> bool:
        try:
            if not os.path.isdir(self.directory):
                os.makedirs(self.directory)
            probe = os.path.join(self.directory, ".write-probe")
            with open(probe, "w", encoding="utf-8") as handle:
                handle.write("ok")
            os.remove(probe)
            return True
        except OSError as exc:
            self._notes.append("cannot use %s: %s" % (self.directory, exc))
            return False

    @property
    def storage_path(self) -> Optional[str]:
        if self.backend == DPAPI_BACKEND:
            return os.path.join(self.directory, CIPHER_FILE_NAME)
        if self.backend == FILE_BACKEND:
            return os.path.join(self.directory, PLAIN_FILE_NAME)
        return None

    def describe(self) -> Dict[str, Any]:
        """Non-secret description for Settings/Diagnostics."""
        encrypted = self.backend == DPAPI_BACKEND
        warning = ""
        if self.backend == FILE_BACKEND:
            warning = (
                "Credentials are stored UNENCRYPTED in a local file readable by "
                "your user account. This machine does not provide a protected "
                "storage API that Cartridge could verify."
            )
        elif self.backend == MEMORY_BACKEND:
            warning = (
                "Credentials are held for this session only and are not saved. "
                "Set them again after a restart, or provide them through "
                "environment variables."
            )
        return {
            "backend": self.backend,
            "encrypted": encrypted,
            "path": self.storage_path,
            "keys_stored": self.keys(),
            "warning": warning,
            "notes": list(self._notes),
        }

    # ------------------------------------------------------------------
    def get(self, key: str) -> Optional[str]:
        with self._lock:
            value = self._read_all().get(key)
            if value is not None:
                self.redactor.register(value)
            return value

    def set(self, key: str, value: Optional[str]) -> None:
        clean_key = str(key).strip()
        if not clean_key:
            raise ValueError("empty key")
        with self._lock:
            data = self._read_all()
            if value is None or str(value) == "":
                data.pop(clean_key, None)
            else:
                data[clean_key] = str(value)
                self.redactor.register(str(value))
            self._write_all(data)

    def delete(self, key: str) -> None:
        self.set(key, None)

    def clear(self) -> None:
        with self._lock:
            self._memory.clear()
            path = self.storage_path
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass

    def keys(self) -> List[str]:
        with self._lock:
            return sorted(self._read_all().keys())

    # ------------------------------------------------------------------
    def _read_all(self) -> Dict[str, str]:
        if self.backend == MEMORY_BACKEND:
            return dict(self._memory)
        path = self.storage_path
        if not path or not os.path.exists(path):
            return dict(self._memory)
        try:
            with open(path, "rb") as handle:
                raw = handle.read()
        except OSError as exc:
            self._notes.append("cannot read %s: %s" % (path, exc))
            return dict(self._memory)
        if not raw:
            return dict(self._memory)
        try:
            if self.backend == DPAPI_BACKEND:
                framed = parse_blob_frame(raw)
                if framed is None:
                    raise ValueError("not a Cartridge credential file")
                payload = dpapi_decrypt(framed)
            else:
                payload = _decode_plain(raw)
            data = json.loads(payload.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("credentials file must contain an object")
        except Exception as exc:
            # A corrupt store must not prevent the app from starting.
            self._notes.append(
                "credentials store at %s could not be read (%s); starting without "
                "saved credentials" % (path, type(exc).__name__)
            )
            return dict(self._memory)
        merged = dict(self._memory)
        merged.update({str(k): str(v) for k, v in data.items()})
        return merged

    def _write_all(self, data: Dict[str, str]) -> None:
        self._memory = dict(data)
        path = self.storage_path
        if not path:
            return
        payload = json.dumps(data, sort_keys=True).encode("utf-8")
        try:
            if self.backend == DPAPI_BACKEND:
                raw = blob_frame(dpapi_encrypt(payload))
            else:
                raw = _encode_plain(payload)
            temporary = path + ".tmp"
            with open(temporary, "wb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            _restrict_permissions(temporary)
            os.replace(temporary, path)
            _restrict_permissions(path)
        except OSError as exc:
            self._notes.append("cannot write %s: %s" % (path, exc))
        except Exception as exc:  # pragma: no cover - DPAPI failure
            self._notes.append(
                "cannot protect credentials (%s); they remain session-only"
                % type(exc).__name__
            )


def _encode_plain(payload: bytes) -> bytes:
    """Base64 framing only - keeps the file out of casual sight, not secure."""
    return base64.b64encode(payload)


def _decode_plain(raw: bytes) -> bytes:
    return base64.b64decode(raw)


def _restrict_permissions(path: str) -> None:
    """Best-effort 0600. Meaningful on POSIX; a no-op on Windows ACLs."""
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


# --------------------------------------------------------------------------
# Windows DPAPI through ctypes (no third-party dependency)
# --------------------------------------------------------------------------
def dpapi_available() -> Tuple[bool, str]:
    """Whether CryptProtectData can be used here."""
    if not sys.platform.startswith("win"):
        return False, "not Windows"
    try:
        import ctypes

        ctypes.windll.crypt32.CryptProtectData  # noqa: B018 - attribute probe
        return True, ""
    except Exception as exc:  # pragma: no cover - Windows only
        return False, "crypt32 unavailable: %s" % exc


def _data_blob(data: bytes):
    """Build a Win32 DATA_BLOB. Raises ImportError off Windows."""
    import ctypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [
            ("cbData", ctypes.c_ulong),
            ("pbData", ctypes.POINTER(ctypes.c_char)),
        ]

    buffer = ctypes.create_string_buffer(data, len(data))
    return DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char)))


def dpapi_encrypt(data: bytes) -> bytes:
    """Encrypt with CryptProtectData (user scope). Windows only."""
    import ctypes

    blob_in = _data_blob(data)
    blob_out = _data_blob(b"")
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)
    )
    if not ok:
        raise OSError("CryptProtectData failed (error %d)" % ctypes.get_last_error())
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


def dpapi_decrypt(data: bytes) -> bytes:
    """Decrypt with CryptUnprotectData. Windows only."""
    import ctypes

    blob_in = _data_blob(data)
    blob_out = _data_blob(b"")
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)
    )
    if not ok:
        raise OSError("CryptUnprotectData failed (error %d)" % ctypes.get_last_error())
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


def blob_frame(data: bytes) -> bytes:
    """Wrap the DPAPI ciphertext so a corrupt or foreign file is detectable.

    A 4-byte magic, a 1-byte version and a big-endian length, then the payload.
    It also lets the tests assert the on-disk shape without needing DPAPI.
    """
    import struct

    return b"CRG1" + struct.pack(">BI", 1, len(data)) + data


def parse_blob_frame(raw: bytes) -> Optional[bytes]:
    import struct

    if not raw or len(raw) < 9 or raw[:4] != b"CRG1":
        return None
    version, length = struct.unpack(">BI", raw[4:9])
    if version != 1 or length != len(raw) - 9:
        return None
    return raw[9:]
