"""Background work: a bounded worker pool and Qt signal plumbing.

Brief sections 10 and 14 are strict about this: nothing that blocks — HTTP,
downloads, folder scans, size measurement, large queries — may run on the GUI
thread, and threads must not be created without limit on a two-core machine.

Design
------
One shared :class:`WorkerPool` wraps ``QThreadPool`` with
``maxThreadCount = WORKER_COUNT`` (3 = cores + 1: enough to overlap network
latency with disk I/O, not enough to thrash a mechanical drive).

Object lifetimes (learned the hard way — see DECISIONS D-012)
------------------------------------------------------------
``QRunnable`` ownership is subtle and getting it wrong segfaults rather than
raising:

* The runnable is created with **``setAutoDelete(True)``**, so ``QThreadPool``
  owns and deletes it after ``run()`` returns. Python must *not* also hold the
  last reference: dropping it while a pool thread is still inside its post-run
  cleanup is a use-after-free.
* Therefore :meth:`WorkerPool.submit` returns a **``TaskHandle``** — a plain
  Python object with no C++ counterpart — rather than the runnable. Cancellation
  and progress reporting go through the handle.
* The handle owns the ``WorkerSignals`` QObject, which must outlive the runnable
  so queued signal deliveries still have a live receiver on the GUI thread.

Signals
-------
``QRunnable`` is not a ``QObject``, so signals live on ``WorkerSignals`` and are
delivered across threads through Qt's queued connections. Callables passed as
``_on_finished`` / ``_on_failed`` / ``_on_progress`` are wrapped so an exception
in UI code can never take down a worker thread.

Cancellation is cooperative: the task receives a ``CancelToken`` (via its
``cancel_event`` parameter, if it declares one) and polls it. Nothing is ever
killed mid-write, which matters because tasks write into the user's game folders.

Database safety: each worker thread gets its own SQLite connection through
:class:`cartridge.db.connection.Database`, so the GUI thread's connection is
never shared across threads.
"""

from __future__ import annotations

import threading
import traceback
import weakref
from typing import Any, Callable, Dict, List, Optional

from PyQt5.QtCore import QObject, QRunnable, QThreadPool, pyqtSignal

#: 2 CPU cores on the target machine; +1 keeps the pipe full during I/O waits.
WORKER_COUNT = 3

#: Anything longer than this gets a visible busy indicator (brief section 14).
BUSY_THRESHOLD_MS = 250


class WorkerSignals(QObject):
    """Signal carrier for a task (QRunnable cannot itself be a QObject).

    Deliberately **parentless and pool-owned**. Qt deletes a QRunnable's
    ``QObject`` children when the runnable is destroyed, and it enforces that a
    child's parent must live in the thread that created the child. A signals
    object created on the GUI thread that got parented to a runnable destroyed on
    a pool thread aborts the process ("Cannot create children for a parent that is
    in a different thread"). Keeping it parentless and referenced by the pool's
    handle removes the whole class of failure.
    """

    finished = pyqtSignal(object)
    failed = pyqtSignal(str, str)
    progress = pyqtSignal(int, int)
    started = pyqtSignal(str)

    def __init__(self):
        super(WorkerSignals, self).__init__(None)


class CancelToken(object):
    """Cooperative cancellation flag shared between the UI and a task."""

    def __init__(self):
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def __call__(self) -> bool:
        return self._event.is_set()

    def reset(self) -> None:
        self._event.clear()


class TaskHandle(object):
    """The caller's view of a submitted task. Pure Python, no C++ lifetime.

    This is what :meth:`WorkerPool.submit` returns. Holding it (or dropping it)
    has no effect on the runnable's lifetime, which is exactly why it is safe to
    hand to UI code.
    """

    def __init__(self, name: str, signals: WorkerSignals, token: CancelToken,
                 task_id: int = 0):
        self.name = name
        self.task_id = task_id
        self.signals = signals
        self.cancel_token = token
        self.done = threading.Event()

    def cancel(self) -> None:
        """Ask the task to stop at its next checkpoint."""
        self.cancel_token.cancel()

    @property
    def cancelled(self) -> bool:
        return self.cancel_token.cancelled

    def wait(self, timeout: Optional[float] = None) -> bool:
        """Block until the task reported back (mainly for tests and shutdown)."""
        return self.done.wait(timeout)


class Worker(QRunnable):
    """Runs one callable off the GUI thread and reports through ``signals``."""

    def __init__(
        self,
        fn: Callable[..., Any],
        signals: WorkerSignals,
        token: CancelToken,
        *args: Any,
        **kwargs: Any
    ):
        """``task_name`` is the pool's own label and is consumed here.

        It uses a name no task would ever declare, so a callable that legitimately
        takes ``name=`` still receives exactly what the caller passed. Popping it
        (rather than taking it as a parameter before ``*args``) is what keeps the
        two namespaces from colliding.
        """
        super(Worker, self).__init__()
        self.fn = fn
        # A plain attribute reference, not a Qt parent/child relationship: the
        # pool's TaskHandle owns this object and keeps it alive until the task has
        # reported back (see WorkerSignals).
        self.signals = signals
        self.cancel_token = token
        self.name = str(kwargs.pop("task_name", "task"))
        self.args = args
        self.kwargs = kwargs
        # QThreadPool deletes this object once run() returns. Python must not
        # race it: submit() hands out a TaskHandle instead of this object.
        self.setAutoDelete(True)

    def run(self) -> None:  # noqa: D102 - QRunnable entry point
        self.signals.started.emit(self.name)
        try:
            kwargs = dict(self.kwargs)
            # Tasks opt into cancellation and progress by declaring the
            # parameters; everything else is left alone so any plain function
            # can be submitted.
            if _accepts_keyword(self.fn, "cancel_event"):
                kwargs.setdefault("cancel_event", self.cancel_token)
            if _accepts_keyword(self.fn, "progress"):
                signals = self.signals
                kwargs.setdefault(
                    "progress",
                    lambda current, total: signals.progress.emit(
                        int(current), int(total)
                    ),
                )
            payload = self.fn(*self.args, **kwargs)
        except Exception as exc:
            detail = traceback.format_exc()
            self.signals.failed.emit(_message_for(exc), detail[-2000:])
            return
        if self.cancel_token.cancelled:
            # Three situations that must not be conflated:
            #  * the task never looked at the token and returned nothing useful
            #    -> cancelled, so the UI does not render an empty result as a
            #    successful one;
            #  * the task stopped at a checkpoint and returned a real partial
            #    result (a partial scan, "stopped-early") -> a successful result
            #    the user can act on, so discarding it would throw away work;
            #  * the task completed normally but the user cancelled in the
            #    meantime, and the cancellation arrived after the payload was
            #    produced -> deliver the payload.
            # The distinguishing question is whether there is anything to show.
            if payload is None:
                self.signals.failed.emit(
                    "cancelled", "The operation was cancelled."
                )
            else:
                self.signals.finished.emit(payload)
            return
        self.signals.finished.emit(payload)


def _accepts_keyword(fn: Callable[..., Any], name: str) -> bool:
    """Whether ``fn`` *explicitly declares* ``name`` as a keyword parameter.

    ``**kwargs`` deliberately does not count. Treating it as an opt-in injected
    ``cancel_event=`` into every lambda passed to the pool, which then failed with
    "takes 0 positional arguments but 1 was given" - a task that looks broken
    rather than one that never asked for cancellation. Injection is opt-in by
    name only; a task that wants the raw event can declare ``**kwargs`` and read
    nothing, or take ``cancel_event`` explicitly.
    """
    try:
        import inspect

        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        return False
    parameter = signature.parameters.get(name)
    if parameter is None:
        return False
    return parameter.kind in (
        parameter.POSITIONAL_OR_KEYWORD,
        parameter.KEYWORD_ONLY,
    )


def _message_for(exc: BaseException) -> str:
    """One-line, user-presentable message for an exception."""
    from cartridge.providers.base import ProviderError, describe_error

    if isinstance(exc, ProviderError):
        return describe_error(exc)
    text = str(exc).strip()
    if not text:
        text = type(exc).__name__
    return text.splitlines()[0][:300]


class WorkerPool(object):
    """The application's single bounded thread pool."""

    def __init__(self, max_threads: int = WORKER_COUNT, shared: bool = False):
        """``shared=False`` (the default) gives this instance a private
        ``QThreadPool``.

        Using ``QThreadPool.globalInstance()`` here is a trap: any other code in
        the process - a test, a plugin, a second window - that calls ``clear()``
        or ``waitForDone()`` on the global pool silently drops *our* queued
        runnables, and the handles waiting on them never report back. The app
        creates exactly one pool, so a private one costs nothing and removes the
        interference entirely. Pass ``shared=True`` only if you deliberately want
        to co-schedule with Qt's global pool.
        """
        self._pool = QThreadPool.globalInstance() if shared else QThreadPool()
        self._pool.setMaxThreadCount(max(1, int(max_threads)))
        self._lock = threading.RLock()
        self._handles: Dict[int, TaskHandle] = {}
        self._groups: Dict[str, List[int]] = {}
        #: (signal, slot) pairs kept alive by the pool for the process lifetime.
        #: Holding them here - rather than letting them live only on the signals
        #: object - avoids the reference cycle described in submit().
        self._connections: List[Any] = []
        self._next_id = 1
        self.submitted = 0
        self.completed = 0
        self.failed = 0
        self.cancelled = 0

    # ------------------------------------------------------------------
    @property
    def max_threads(self) -> int:
        return int(self._pool.maxThreadCount())

    def active_count(self) -> int:
        return int(self._pool.activeThreadCount())

    def pending_count(self) -> int:
        """Tasks submitted but not yet reported back (queued or running)."""
        with self._lock:
            return len(self._handles)

    def submit(
        self,
        fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any
    ) -> TaskHandle:
        """Queue ``fn`` for background execution. Returns a :class:`TaskHandle`.

        Reserved keywords, consumed here rather than passed to ``fn``:

        ``_name``        task-group label, used by :meth:`cancel` and the status bar
        ``_on_finished`` ``callable(payload)`` on success
        ``_on_failed``   ``callable(message, detail)`` on failure
        ``_on_progress`` ``callable(current, total)`` if the task reports progress

        The underscore prefix keeps them out of the way of a callable's own
        arguments: a task that legitimately takes ``name=`` still works.
        """
        name = str(kwargs.pop("_name", "task"))
        on_finished = kwargs.pop("_on_finished", None)
        on_failed = kwargs.pop("_on_failed", None)
        on_progress = kwargs.pop("_on_progress", None)

        signals = WorkerSignals()
        token = CancelToken()
        with self._lock:
            task_id = self._next_id
            self._next_id += 1
            handle = TaskHandle(name, signals, token, task_id)
            self._handles[task_id] = handle
            self._groups.setdefault(name, []).append(task_id)

        # NOTE ON LIFETIMES: these connections are stored *by the pool*, never on
        # the signals object. A lambda that captures `self` and lives on an object
        # the pool owns creates a reference cycle (pool -> handle -> signals ->
        # connection -> lambda -> pool) that only the garbage collector can break,
        # and breaking it in the middle of a signal emission frees the receiver
        # while Qt is still calling into it - a segfault, not a Python error.
        # Capturing a weakref means the connection holds no strong reference to
        # the pool at all.
        pool_ref = weakref.ref(self)

        def report_finished(payload, _id=task_id, _ref=pool_ref):
            target = _ref()
            if target is not None:
                target._report(_id, False, "", payload)

        def report_failed(message, detail, _id=task_id, _ref=pool_ref):
            target = _ref()
            if target is not None:
                target._report(_id, True, message, detail)

        self._connect(signals.finished, report_finished)
        self._connect(signals.failed, report_failed)

        # Slot signatures must match the signals exactly: a one-argument slot
        # connected to failed(str, str) makes Qt deliver two arguments into one
        # parameter, which corrupts the call instead of raising a TypeError.
        if on_finished is not None:
            self._connect(signals.finished, _guard(on_finished))
        if on_failed is not None:
            self._connect(signals.failed, _guard2(on_failed))
        if on_progress is not None:
            self._connect(signals.progress, _guard2(on_progress))

        # `name` goes in as a keyword so Worker can pop it; passing it
        # positionally would make it the task's first argument.
        worker = Worker(fn, signals, token, *args, task_name=name, **kwargs)
        self.submitted += 1
        self._pool.start(worker)
        # `worker` deliberately goes out of scope here: QThreadPool owns it.
        return handle

    def _connect(self, signal: Any, slot: Callable[..., None]) -> None:
        """Connect and remember the pair, so the slot outlives the emission."""
        signal.connect(slot)
        self._connections.append((signal, slot))

    def _report(self, task_id: int, failed: bool, message: str = "",
                detail: str = "") -> None:
        """Runs on the GUI thread after the task reported back.

        The handle is removed from the pool's dicts *last*. Popping it first
        dropped the only strong reference to its ``WorkerSignals`` while this very
        lambda was still executing inside that object's signal emission - a
        use-after-free that segfaulted instead of raising. Everything that can be
        touched after the release is read into a local first.
        """
        with self._lock:
            handle = self._handles.get(task_id)
            name = handle.name if handle is not None else ""
            group = self._groups.get(name)
            if group and task_id in group:
                group.remove(task_id)
            if group is not None and not group:
                self._groups.pop(name, None)
            self.completed += 1
            if failed:
                self.failed += 1
                if message == "cancelled":
                    self.cancelled += 1
            if handle is not None:
                handle.done.set()
            # Release the pool's reference only after every use above is done.
            self._handles.pop(task_id, None)

    # ------------------------------------------------------------------
    def cancel(self, name: Optional[str] = None) -> int:
        """Cancel one named task group, or everything. Cooperative."""
        count = 0
        with self._lock:
            groups = [name] if name else list(self._groups.keys())
            for group in groups:
                for task_id in list(self._groups.get(group, [])):
                    handle = self._handles.get(task_id)
                    if handle is not None:
                        handle.cancel()
                        count += 1
        return count

    def cancel_all(self) -> int:
        return self.cancel(None)

    def wait(self, timeout_ms: int = -1) -> bool:
        """Block until the queue drains (used at shutdown and by tests)."""
        return bool(self._pool.waitForDone(int(timeout_ms)))

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            pending_by_task = {
                name: len(ids) for name, ids in self._groups.items() if ids
            }
        return {
            "max_threads": self.max_threads,
            "active_threads": self.active_count(),
            "pending": self.pending_count(),
            "pending_by_task": pending_by_task,
            "submitted": self.submitted,
            "completed": self.completed,
            "failed": self.failed,
            "cancelled": self.cancelled,
        }

    def shutdown(self, timeout_ms: int = 4000) -> bool:
        """Cancel everything, then wait briefly. Called on application exit."""
        self.cancel_all()
        drained = self.wait(timeout_ms)
        try:
            # Drops queued-but-unstarted runnables. They never emit a signal, so
            # their handles are released here instead.
            self._pool.clear()
        except RuntimeError:
            pass
        with self._lock:
            for handle in self._handles.values():
                handle.done.set()
            self._handles.clear()
            self._groups.clear()
        return drained


def _guard(fn: Callable[[Any], None]) -> Callable[[Any], None]:
    """Never let a UI callback exception take down a worker thread."""

    def wrapped(payload: Any) -> None:
        try:
            fn(payload)
        except Exception:
            traceback.print_exc()

    return wrapped


def _guard2(fn: Callable[..., None]) -> Callable[..., None]:
    def wrapped(*args: Any) -> None:
        try:
            fn(*args)
        except Exception:
            traceback.print_exc()

    return wrapped
