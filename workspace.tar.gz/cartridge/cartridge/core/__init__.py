"""Shared application core: models, filtering/sorting, bounded worker pool, configuration."""
