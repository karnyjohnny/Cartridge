"""Search, filter and sort specifications.

One source of truth: this module turns a :class:`FilterSpec` into a parameterized
SQL ``WHERE`` fragment plus an ``ORDER BY`` clause, and the repository executes it.
There is deliberately **no** second in-memory implementation of the same rules —
duplicated filter logic is how a UI ends up showing a different set than the one
it counted.

Everything user- or provider-supplied arrives as a bound parameter, never as SQL
text. The only strings interpolated into SQL here come from the closed registries
``SORT_FIELDS`` and ``STATE_*`` constants defined below.

Unknown values sort consistently: NULLs always last, regardless of direction
(brief section 12).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------
# Sort registry: label -> (SQL expression, "NULLs last" helper expression)
# --------------------------------------------------------------------------
# sort_title is a maintained column (article moved to the end, recomputed
# whenever title or user_title changes), so ordering can use it directly and
# still benefit from idx_games_sort_title. user_title is kept as a fallback for
# rows written before that column existed.
EFFECTIVE_TITLE = (
    "COALESCE(NULLIF(sort_title, ''), NULLIF(user_title, ''),"
    " NULLIF(title, ''), folder_path)"
)
EFFECTIVE_YEAR = "COALESCE(user_release_year, release_year)"
EFFECTIVE_RATING = "COALESCE(user_rating, rating)"
EFFECTIVE_DEVELOPER = "COALESCE(NULLIF(user_developer, ''), developer)"

SORT_FIELDS: Dict[str, Tuple[str, str]] = {
    # label: (order expression, null-flag expression)
    "title": (EFFECTIVE_TITLE, "0"),
    "year": (EFFECTIVE_YEAR, "%s IS NULL" % EFFECTIVE_YEAR),
    "rating": (EFFECTIVE_RATING, "%s IS NULL" % EFFECTIVE_RATING),
    "added": ("added_at", "0"),
    "developer": (EFFECTIVE_DEVELOPER, "%s IS NULL" % EFFECTIVE_DEVELOPER),
    "folder": ("folder_path", "0"),
    "size": ("folder_size_bytes", "folder_size_bytes IS NULL"),
    "last_played": ("last_verified_at", "last_verified_at IS NULL"),
}

DEFAULT_SORT = "title"

# Metadata states considered "incomplete" for the Needs-attention filter.
INCOMPLETE_STATES = ("none", "partial", "error")

VIEW_ALL = "all"
VIEW_FAVOURITES = "favourites"
VIEW_NEEDS_ATTENTION = "needs_attention"
VIEW_MISSING_ARTWORK = "missing_artwork"
VIEW_MISSING_FOLDER = "missing_folder"
VIEW_INCOMPLETE = "incomplete"
VIEW_RECENT = "recent"

VIEWS = (
    VIEW_ALL, VIEW_FAVOURITES, VIEW_NEEDS_ATTENTION, VIEW_MISSING_ARTWORK,
    VIEW_MISSING_FOLDER, VIEW_INCOMPLETE, VIEW_RECENT,
)


@dataclass
class FilterSpec(object):
    """Everything that narrows the collection list."""

    query: str = ""
    view: str = VIEW_ALL
    genres: List[str] = field(default_factory=list)
    content_types: List[str] = field(default_factory=list)
    decades: List[str] = field(default_factory=list)          # "1990s"
    developers: List[str] = field(default_factory=list)
    platforms: List[str] = field(default_factory=list)
    root_id: Optional[int] = None
    min_rating: Optional[float] = None
    sort: str = DEFAULT_SORT
    descending: bool = False
    limit: Optional[int] = None
    offset: int = 0

    def is_empty(self) -> bool:
        return not (
            self.query or self.genres or self.content_types or self.decades
            or self.developers or self.platforms or self.min_rating is not None
            or self.view != VIEW_ALL or self.root_id is not None
        )

    def clone(self) -> "FilterSpec":
        return FilterSpec(
            query=self.query,
            view=self.view,
            genres=list(self.genres),
            content_types=list(self.content_types),
            decades=list(self.decades),
            developers=list(self.developers),
            platforms=list(self.platforms),
            root_id=self.root_id,
            min_rating=self.min_rating,
            sort=self.sort,
            descending=self.descending,
            limit=self.limit,
            offset=self.offset,
        )


def decade_range(decade: str) -> Optional[Tuple[int, int]]:
    """``"1990s"`` -> ``(1990, 1999)``. Returns None for unparsable input."""
    text = str(decade).strip().lower().rstrip("s")
    if not text.isdigit() or len(text) != 4:
        return None
    start = int(text)
    return (start, start + 9)


def build_where(spec: FilterSpec) -> Tuple[str, List[Any]]:
    """Return ``(sql_fragment, params)``. The fragment has no leading AND."""
    clauses: List[str] = []
    params: List[Any] = []

    query = (spec.query or "").strip()
    if query:
        # AND-of-tokens, not one blob LIKE: "witcher 3 wild" must match
        # "The Witcher 3: Wild Hunt" even though the stored concatenated key has
        # no spaces. Each token is folded the same way the blob was folded, and
        # both the spaced and the concatenated forms live in search_blob.
        tokens = []
        for raw in query.split():
            folded = _fold(raw)
            if folded and folded not in tokens:
                tokens.append(folded)
        if not tokens:
            folded_all = _fold(query)
            if folded_all:
                tokens = [folded_all]
        for token in tokens:
            clauses.append("g.search_blob LIKE ?")
            params.append("%%%s%%" % token)

    if spec.view == VIEW_FAVOURITES:
        clauses.append("g.favourite = 1")
    elif spec.view == VIEW_INCOMPLETE:
        clauses.append(
            "g.metadata_state IN (%s)" % ",".join("?" * len(INCOMPLETE_STATES))
        )
        params.extend(INCOMPLETE_STATES)
    elif spec.view == VIEW_MISSING_ARTWORK:
        clauses.append(
            "NOT EXISTS (SELECT 1 FROM assets a WHERE a.game_id = g.id AND a.state = 'ok')"
        )
    elif spec.view == VIEW_MISSING_FOLDER:
        clauses.append("g.folder_state != 'present'")
    elif spec.view == VIEW_NEEDS_ATTENTION:
        # The same conditions the Manager shows as reasons, expressed once.
        clauses.append(
            "("
            " g.folder_state != 'present'"
            " OR g.metadata_state IN (%s)"
            " OR NOT EXISTS (SELECT 1 FROM assets a WHERE a.game_id = g.id AND a.state = 'ok')"
            ")" % ",".join("?" * len(INCOMPLETE_STATES))
        )
        params.extend(INCOMPLETE_STATES)

    if spec.root_id is not None:
        clauses.append("g.root_id = ?")
        params.append(int(spec.root_id))

    if spec.genres:
        clauses.append(
            "EXISTS (SELECT 1 FROM game_genres gg JOIN genres gen ON gen.id = gg.genre_id"
            " WHERE gg.game_id = g.id AND gen.name_key IN (%s))" % ",".join("?" * len(spec.genres))
        )
        params.extend(_fold(name) for name in spec.genres)

    if spec.platforms:
        clauses.append(
            "EXISTS (SELECT 1 FROM game_platforms gp JOIN platforms pf ON pf.id = gp.platform_id"
            " WHERE gp.game_id = g.id AND pf.name_key IN (%s))" % ",".join("?" * len(spec.platforms))
        )
        params.extend(_fold(name) for name in spec.platforms)

    if spec.content_types:
        clauses.append(
            "EXISTS (SELECT 1 FROM game_content_types gct"
            " JOIN content_types ct ON ct.id = gct.content_type_id"
            " WHERE gct.game_id = g.id AND ct.name_key IN (%s))"
            % ",".join("?" * len(spec.content_types))
        )
        params.extend(_fold(name) for name in spec.content_types)

    if spec.developers:
        clauses.append(
            "COALESCE(NULLIF(g.user_developer, ''), g.developer) IN (%s)"
            % ",".join("?" * len(spec.developers))
        )
        params.extend(spec.developers)

    if spec.decades:
        ranges = []
        for decade in spec.decades:
            parsed = decade_range(decade)
            if parsed:
                ranges.append(parsed)
        if ranges:
            ors = []
            for low, high in ranges:
                ors.append("(%s BETWEEN ? AND ?)" % EFFECTIVE_YEAR)
                params.extend([low, high])
            clauses.append("(%s)" % " OR ".join(ors))

    if spec.min_rating is not None:
        clauses.append("%s >= ?" % EFFECTIVE_RATING)
        params.append(float(spec.min_rating))

    if not clauses:
        return "", []
    return " AND ".join(clauses), params


def build_order(spec: FilterSpec) -> str:
    """Return an ``ORDER BY`` clause (no leading keyword) for the spec."""
    key = spec.sort if spec.sort in SORT_FIELDS else DEFAULT_SORT
    expression, null_flag = SORT_FIELDS[key]
    direction = "DESC" if spec.descending else "ASC"
    if null_flag == "0":
        # Text/never-null columns: plain ordering, but keep a deterministic
        # tie-break so paging is stable.
        return "%s %s, g.id ASC" % (expression, direction)
    # NULLs last regardless of direction.
    return "%s ASC, %s %s, g.id ASC" % (null_flag, expression, direction)


def build_limit_offset(spec: FilterSpec) -> Tuple[str, List[Any]]:
    params: List[Any] = []
    sql = ""
    if spec.limit is not None:
        sql += " LIMIT ?"
        params.append(int(spec.limit))
        # SQLite requires LIMIT before OFFSET
        sql += " OFFSET ?"
        params.append(max(0, int(spec.offset)))
    elif spec.offset:
        sql += " LIMIT -1 OFFSET ?"
        params.append(max(0, int(spec.offset)))
    return sql, params


def _fold(value: str) -> str:
    """Fold a facet/query value the same way the stored keys are folded."""
    from cartridge.text import search_key

    return search_key(value)


def facet_rows_sql() -> Dict[str, str]:
    """SQL used to populate the sidebar facets (counts per facet value)."""
    return {
        "genres": (
            "SELECT gen.name AS label, COUNT(DISTINCT gg.game_id) AS n"
            " FROM genres gen JOIN game_genres gg ON gg.genre_id = gen.id"
            " GROUP BY gen.id HAVING n > 0 ORDER BY n DESC, gen.name ASC"
        ),
        "content_types": (
            "SELECT ct.name AS label, COUNT(gct.game_id) AS n"
            " FROM content_types ct LEFT JOIN game_content_types gct ON gct.content_type_id = ct.id"
            " GROUP BY ct.id ORDER BY ct.sort_order ASC, ct.name ASC"
        ),
        "decades": (
            "SELECT (CAST(%s / 10 AS INTEGER) * 10) || 's' AS label, COUNT(*) AS n"
            " FROM games g WHERE %s IS NOT NULL"
            " GROUP BY label ORDER BY label DESC" % (EFFECTIVE_YEAR, EFFECTIVE_YEAR)
        ),
        "developers": (
            "SELECT COALESCE(NULLIF(g.user_developer, ''), g.developer) AS label, COUNT(*) AS n"
            " FROM games g WHERE label IS NOT NULL AND label != ''"
            " GROUP BY label ORDER BY n DESC, label ASC LIMIT 200"
        ),
        "platforms": (
            "SELECT pf.name AS label, COUNT(DISTINCT gp.game_id) AS n"
            " FROM platforms pf JOIN game_platforms gp ON gp.platform_id = pf.id"
            " GROUP BY pf.id HAVING n > 0 ORDER BY n DESC, pf.name ASC"
        ),
    }


def sort_labels() -> Sequence[str]:
    return tuple(SORT_FIELDS.keys())
